export class User{
    ime: string;
    prezime: string;
    korisnicko_ime: string;
    lozinka: string;
    tel: string
    email: string;
    tip: string;
    organizacija: string;
    adresa_org: string;
    broj_org: number;
    slika: string;
    status: string;
    token: string;
    token_date: Date;
}