export class Message{
    from: string;
    to: string;
    tekst: string;
    datum: Date;
    fromImg: string;
    toImg: string;
    radionica: string;
    _idR: string;
}