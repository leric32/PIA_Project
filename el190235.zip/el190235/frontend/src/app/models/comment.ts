export class Comment{
    ucesnik: string;
    radionica: string;
    komentar: string;
    datum: Date;
}