export class Like{
    ucesnik: string;
    radionica: string;
    datum: Date;
}